for am in range(-0 , 11):
    print( am ,"Am")
for pm in range(11,24):
    print(pm ,"Pm")

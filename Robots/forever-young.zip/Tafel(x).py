while True:
    tafel = int(input("welke tafel wil je ? 1 t/m 10 "))
    for x in range(1,11):
        print(x , "x", tafel , "=" , x * tafel)

for k in range(20, 51 , 2):
    print(k)
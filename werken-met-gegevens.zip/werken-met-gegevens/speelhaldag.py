Persoon=4
toegangsticket=7.45
minuteninspelen=45
kostperpersoon=0.37
inminuten=5

print(toegangsticket*Persoon+kostperpersoon*minuteninspelen)
print("Dit geweldige dagje-uit met 4 mensen in de Speelhal met 45 minuten VR kost je maar 44.44 euro")
croissantjes=17
prijsvoorndecroissantjes=0.39
stokbroden=2
prijsvoorstokbroden=2.78
kortingsbonnen=3
prijsinkortingsbonnen=0.50

print(prijsvoorndecroissantjes*croissantjes+prijsvoorstokbroden*stokbroden-prijsinkortingsbonnen*kortingsbonnen)
print("De feestlunch kost je bij de bakker 18.88 euro voor de 17 croissantjes en de 2 stokbroden als de 3 kortingsbonnen nog geldig zijn!")